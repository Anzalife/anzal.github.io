# Portfolio Website - Complete Setup Guide

## Quick Start (5 minutes)

### Step 1: Install Node.js
Download from: https://nodejs.org/ (LTS version recommended)

### Step 2: Create a New React Project
Open VS Code and open a terminal (Ctrl+` or View → Terminal)

```bash
npx create-react-app fatuma-portfolio
cd fatuma-portfolio
```

### Step 3: Replace Files
You'll need to replace some files in your project:

1. **Delete** these files from `src/`:
   - `App.js`
   - `App.css`

2. **Copy** these new files into `src/`:
   - `App.jsx` (the portfolio component)
   - `index.css` (global styles)

3. **Update** `src/index.js` - replace content with the provided code

### Step 4: Install Dependencies
In terminal, run:
```bash
npm install lucide-react
```

### Step 5: Start Development Server
```bash
npm start
```

The website will open at: http://localhost:3000

---

## File-by-File Setup

### File 1: `package.json`
This file is automatically created by `create-react-app`. Just make sure `lucide-react` is installed (Step 4 above).

### File 2: `src/index.js`
Replace entire content with the code below:

```javascript
import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
```

### File 3: `src/App.jsx`
This is the main portfolio component (already provided separately)

### File 4: `src/index.css`
Replace with the code below:

```css
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

html {
  scroll-behavior: smooth;
}

body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',
    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
    sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  background-color: #ffffff;
  color: #1f2937;
}

code {
  font-family: source-code-pro, Menlo, Monaco, Consolas, 'Courier New',
    monospace;
}

/* Tailwind animations */
@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.animate-in {
  animation: fadeIn 0.3s ease-out;
}

/* Scrollbar styling */
::-webkit-scrollbar {
  width: 10px;
}

::-webkit-scrollbar-track {
  background: #f1f5f9;
}

::-webkit-scrollbar-thumb {
  background: #cbd5e1;
  border-radius: 5px;
}

::-webkit-scrollbar-thumb:hover {
  background: #94a3b8;
}
```

---

## Project Structure

```
fatuma-portfolio/
├── node_modules/
├── public/
│   ├── index.html
│   └── favicon.ico
├── src/
│   ├── App.jsx                 (Portfolio component)
│   ├── index.js                (Entry point)
│   ├── index.css               (Global styles)
│   └── index.html
├── package.json
├── package-lock.json
└── README.md
```

---

## Common Commands

```bash
# Start development server
npm start

# Build for production
npm run build

# Run tests
npm test

# Stop the server
Ctrl + C
```

---

## Customization Guide

### 1. Change Colors
The portfolio uses Tailwind CSS classes. To change the blue/indigo theme:

Find these in `App.jsx`:
- `from-blue-600 to-indigo-600` → Change to your preferred colors
- `text-blue-600` → Update accent color
- `from-blue-50 to-indigo-50` → Update background gradients

Tailwind color options:
- `blue`, `purple`, `green`, `pink`, `red`, `yellow`, `cyan`, etc.
- Numbers: 50, 100, 200, 300, 400, 500, 600, 700, 800, 900

Example: `from-green-600 to-emerald-600` for green theme

### 2. Update Personal Information
Replace these in `App.jsx`:
- Phone: `+254 722 214 485`
- Email: `fatumaabdulwaheed@gmail.com`
- LinkedIn URL: `www.linkedin.com/in/fatuma`
- Social media links

### 3. Update Project Details
Edit the `projects` array in App.jsx to update:
- Project titles, descriptions, features
- Design process steps
- Tools used
- Outcomes

### 4. Update Skills
Edit the `skills` object in App.jsx to add/remove skills by category

---

## Deploy to the Web

### Option 1: Vercel (Recommended - 2 minutes)
1. Build your project: `npm run build`
2. Go to: https://vercel.com
3. Sign up with GitHub
4. Click "New Project"
5. Select your GitHub repository
6. Click "Deploy"
7. Your site will be live at: `yourname.vercel.app`

### Option 2: Netlify
1. Build your project: `npm run build`
2. Go to: https://netlify.com
3. Drag and drop your `build` folder
4. Your site is live!

### Option 3: GitHub Pages
1. Update `package.json` homepage: `"homepage": "https://yourusername.github.io/fatuma-portfolio"`
2. Run: `npm run build`
3. Push to GitHub
4. Go to repo Settings → Pages → select `gh-pages` branch

---

## Troubleshooting

**Error: "npm is not recognized"**
- Node.js not installed. Download from nodejs.org and restart VS Code

**Error: "module 'lucide-react' not found"**
- Run: `npm install lucide-react`

**Port 3000 already in use**
- Run: `npm start -- --port 3001`

**Changes not showing**
- Refresh browser (Ctrl+R or Cmd+R)
- Check VS Code terminal for errors

---

## Next Steps

1. ✅ Set up the project locally
2. ✅ Customize with your information
3. ✅ Test on localhost:3000
4. ✅ Deploy to Vercel/Netlify
5. ✅ Share your portfolio link with companies

---

## Support Resources

- React docs: https://react.dev
- Tailwind CSS: https://tailwindcss.com
- Lucide Icons: https://lucide.dev
- Node.js: https://nodejs.org

Good luck! 🚀
