import React, { useState } from 'react';
import { Menu, X, ExternalLink, ChevronDown } from 'lucide-react';

export default function Portfolio() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeProject, setActiveProject] = useState(null);

  const projects = [
    {
      id: 1,
      title: "Phase 4 Schools",
      subtitle: "School Discovery & Selection Platform",
      tagline: "Helping parents find the perfect school for their children",
      image: "🎓",
      color: "from-blue-50 to-indigo-50",
      accent: "text-blue-600",
      description: "A comprehensive mobile app that transforms how parents research and select private schools.",
      highlights: [
        "Extensive database of school profiles, reviews & ratings",
        "Step-by-step admissions guidance",
        "Financial planning tools for tuition estimation",
        "School comparison feature (side-by-side analysis)",
        "Community forum for parent connections"
      ],
      process: [
        { step: "Research", detail: "Competitive analysis vs GreatSchools.org & Niche.com" },
        { step: "User Testing", detail: "Cognitive walkthrough with 45-min completion time" },
        { step: "Design", detail: "Low, Mid & High-fidelity wireframes" },
        { step: "Validation", detail: "Usability testing proved ease of use" }
      ],
      features: [
        "Smart search with filters (location, curriculum, extracurriculars)",
        "Detailed school information & contact management",
        "Favorites & notes system",
        "Application progress tracker",
        "Notification system for deadlines"
      ],
      outcome: "Users could easily collect & analyze school data in 45 minutes with 100% task completion rate",
      tools: ["Figma", "Prototyping", "User Research", "UX Testing"]
    },
    {
      id: 2,
      title: "BudgetHut",
      subtitle: "Financial Literacy for Children",
      tagline: "Unlock your money superpowers with engaging financial education",
      image: "💰",
      color: "from-green-50 to-emerald-50",
      accent: "text-green-600",
      description: "A web and mobile platform empowering children with essential financial knowledge through interactive, age-appropriate content.",
      highlights: [
        "Addresses critical gap in financial education for children",
        "Interactive, engaging & accessible learning platform",
        "Comprehensive financial literacy curriculum",
        "Desktop and mobile optimized experiences",
        "Supports long-term financial responsibility"
      ],
      process: [
        { step: "Discovery", detail: "Problem validation & hypothesis testing" },
        { step: "Research", detail: "User personas & empathy mapping" },
        { step: "Strategy", detail: "Card sorting & information architecture" },
        { step: "Design", detail: "Low to high-fidelity wireframes" }
      ],
      features: [
        "Interactive home dashboard",
        "Structured course curriculum",
        "Calendar & progress tracking",
        "Age-appropriate content design",
        "Gamification elements"
      ],
      outcome: "Created a complete design system with motion guidelines, voice & tone, and validated high-fidelity prototypes",
      tools: ["Figma", "Design Systems", "Motion Design", "User Research"]
    }
  ];

  const skills = {
    Design: ["UX/UI Design", "Product Design", "Wireframing", "Prototyping", "Design Systems", "User Research", "Usability Testing"],
    Development: ["Frontend Development", "HTML/CSS", "React", "Responsive Design"],
    Digital: ["SEO", "Content Creation", "Social Media Management", "Meta Business Suite", "Canva"],
    Tools: ["Figma", "Google Workspace", "Slack", "Trello/Asana", "Adobe Creative Suite"],
    Languages: ["English (Fluent)", "Swahili (Native)", "Somali (Native)"]
  };

  return (
    <div className="min-h-screen bg-white overflow-hidden">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-white/95 backdrop-blur-sm border-b border-gray-100 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-lg">F</span>
            </div>
            <span className="font-bold text-xl text-gray-900">Fatuma</span>
          </div>
          
          {/* Desktop Menu */}
          <div className="hidden md:flex gap-8 items-center">
            <a href="#work" className="text-gray-700 hover:text-gray-900 transition">Work</a>
            <a href="#about" className="text-gray-700 hover:text-gray-900 transition">About</a>
            <a href="#skills" className="text-gray-700 hover:text-gray-900 transition">Skills</a>
            <a href="#contact" className="px-6 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-full hover:shadow-lg transition">
              Get in Touch
            </a>
          </div>

          {/* Mobile Menu Button */}
          <button onClick={() => setMenuOpen(!menuOpen)} className="md:hidden">
            {menuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {menuOpen && (
          <div className="md:hidden border-t border-gray-100 bg-white">
            <div className="px-6 py-4 flex flex-col gap-4">
              <a href="#work" className="text-gray-700">Work</a>
              <a href="#about" className="text-gray-700">About</a>
              <a href="#skills" className="text-gray-700">Skills</a>
              <a href="#contact" className="px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-lg text-center">
                Get in Touch
              </a>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-6 relative overflow-hidden">
        <div className="absolute inset-0 opacity-5">
          <div className="absolute top-20 left-10 w-72 h-72 bg-blue-300 rounded-full mix-blend-multiply filter blur-3xl"></div>
          <div className="absolute top-40 right-10 w-72 h-72 bg-indigo-300 rounded-full mix-blend-multiply filter blur-3xl"></div>
        </div>

        <div className="max-w-4xl mx-auto text-center relative z-10">
          <h1 className="text-5xl md:text-7xl font-bold text-gray-900 mb-6 leading-tight">
            Designing <span className="bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">meaningful</span> digital products
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto leading-relaxed">
            UX/UI Designer & Product Designer based in Nairobi. I create user-centered designs that solve real problems and empower people.
          </p>
          <div className="flex gap-4 justify-center flex-wrap">
            <button className="px-8 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-full hover:shadow-xl transition font-medium">
              View My Work
            </button>
            <button className="px-8 py-3 border-2 border-gray-300 text-gray-900 rounded-full hover:border-gray-400 transition font-medium">
              Download Resume
            </button>
          </div>
        </div>
      </section>

      {/* Work Section */}
      <section id="work" className="py-20 px-6 bg-gray-50">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-gray-900 mb-16">Featured Work</h2>

          <div className="space-y-12">
            {projects.map((project) => (
              <div
                key={project.id}
                className="bg-white rounded-2xl overflow-hidden hover:shadow-xl transition cursor-pointer"
                onClick={() => setActiveProject(activeProject === project.id ? null : project.id)}
              >
                <div className={`bg-gradient-to-br ${project.color} px-8 py-12 md:p-16 flex items-start justify-between`}>
                  <div className="flex-1">
                    <div className="text-5xl mb-4">{project.image}</div>
                    <h3 className={`text-3xl md:text-4xl font-bold ${project.accent} mb-2`}>
                      {project.title}
                    </h3>
                    <p className="text-gray-700 text-lg mb-4">{project.subtitle}</p>
                    <p className="text-gray-600">{project.description}</p>
                  </div>
                  <div className="hidden md:block text-4xl opacity-10">
                    {project.image}
                  </div>
                </div>

                {/* Expanded Project Details */}
                {activeProject === project.id && (
                  <div className="px-8 md:p-16 border-t border-gray-200 bg-gray-50 animate-in fade-in">
                    <div className="grid md:grid-cols-2 gap-12">
                      <div>
                        <h4 className="text-lg font-bold text-gray-900 mb-4">Key Features</h4>
                        <ul className="space-y-3">
                          {project.features.map((feature, idx) => (
                            <li key={idx} className="flex gap-3 text-gray-700">
                              <span className={`${project.accent} font-bold`}>✓</span>
                              {feature}
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div>
                        <h4 className="text-lg font-bold text-gray-900 mb-4">Design Process</h4>
                        <div className="space-y-3">
                          {project.process.map((item, idx) => (
                            <div key={idx} className="pb-3 border-b border-gray-300 last:border-0">
                              <p className={`font-bold ${project.accent}`}>{item.step}</p>
                              <p className="text-sm text-gray-600">{item.detail}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div className="mt-8 pt-8 border-t border-gray-300">
                      <h4 className="text-lg font-bold text-gray-900 mb-3">Outcome</h4>
                      <p className={`text-gray-700 mb-6 ${project.accent} font-semibold`}>{project.outcome}</p>

                      <div className="flex gap-2 flex-wrap">
                        {project.tools.map((tool, idx) => (
                          <span key={idx} className="px-4 py-2 bg-white border border-gray-300 rounded-full text-sm text-gray-700">
                            {tool}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 px-6">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl font-bold text-gray-900 mb-12">About Me</h2>

          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <p className="text-lg text-gray-700 mb-6 leading-relaxed">
                I'm a UX/UI and Product Designer with 5+ years of experience creating digital products that matter. My journey spans from virtual assistance and digital marketing to designing comprehensive mobile applications that solve real problems.
              </p>
              <p className="text-lg text-gray-700 mb-6 leading-relaxed">
                I'm passionate about understanding user needs, conducting thorough research, and translating insights into beautiful, functional designs. Every project is an opportunity to create meaningful impact.
              </p>
              <p className="text-lg text-gray-700 leading-relaxed">
                Based in Nairobi, Kenya, with fluency in English, Swahili, and Somali, I'm uniquely positioned to design for African markets and global audiences.
              </p>
            </div>

            <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl p-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">By The Numbers</h3>
              <div className="space-y-6">
                <div>
                  <p className="text-4xl font-bold text-blue-600">5+</p>
                  <p className="text-gray-600">Years of Experience</p>
                </div>
                <div>
                  <p className="text-4xl font-bold text-blue-600">2</p>
                  <p className="text-gray-600">Major Product Projects</p>
                </div>
                <div>
                  <p className="text-4xl font-bold text-blue-600">3</p>
                  <p className="text-gray-600">Languages (English, Swahili, Somali)</p>
                </div>
                <div>
                  <p className="text-4xl font-bold text-blue-600">100%</p>
                  <p className="text-gray-600">User Task Completion Rate</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="py-20 px-6 bg-gray-50">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl font-bold text-gray-900 mb-12">Skills & Expertise</h2>

          <div className="grid md:grid-cols-2 gap-12">
            {Object.entries(skills).map(([category, items]) => (
              <div key={category}>
                <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                  <span className="w-2 h-2 bg-blue-600 rounded-full"></span>
                  {category}
                </h3>
                <div className="flex flex-wrap gap-2">
                  {items.map((skill, idx) => (
                    <span
                      key={idx}
                      className="px-4 py-2 bg-white border border-gray-200 rounded-lg text-sm text-gray-700 hover:border-blue-300 hover:bg-blue-50 transition"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold text-gray-900 mb-6">Let's Work Together</h2>
          <p className="text-xl text-gray-600 mb-12">
            I'm always interested in hearing about new projects and opportunities. Feel free to reach out!
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <a
              href="tel:+254722214485"
              className="px-8 py-4 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-full hover:shadow-lg transition font-medium inline-flex items-center justify-center gap-2"
            >
              <span>📞 +254 722 214 485</span>
            </a>
            <a
              href="mailto:fatumaabdulwaheed@gmail.com"
              className="px-8 py-4 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-full hover:shadow-lg transition font-medium inline-flex items-center justify-center gap-2"
            >
              <span>✉️ fatumaabdulwaheed@gmail.com</span>
            </a>
          </div>

          <div className="flex gap-6 justify-center">
            <a href="https://www.linkedin.com/in/fatuma" className="text-gray-600 hover:text-blue-600 transition">
              <span className="text-lg">LinkedIn</span>
            </a>
            <a href="https://dribbble.com" className="text-gray-600 hover:text-pink-600 transition">
              <span className="text-lg">Dribbble</span>
            </a>
            <a href="https://behance.net" className="text-gray-600 hover:text-blue-600 transition">
              <span className="text-lg">Behance</span>
            </a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8 px-6 text-center">
        <div className="max-w-4xl mx-auto">
          <p className="text-gray-400">© 2025 Fatuma Abdiwahid Sheikh. All rights reserved.</p>
          <p className="text-gray-500 text-sm mt-2">Based in Nairobi, Kenya • Available for freelance & full-time roles</p>
        </div>
      </footer>
    </div>
  );
}
