# 🚀 QUICK START GUIDE - VS Code Setup

## STEP-BY-STEP (Copy & Paste Commands)

### STEP 1: Install Node.js
**Download from:** https://nodejs.org/ (Choose LTS version)
- Install it (just click next, next, next)
- Restart your computer
- Verify installation - Open Command Prompt/Terminal and type:
  ```
  node --version
  npm --version
  ```
  You should see version numbers

---

### STEP 2: Create the Project
Open VS Code, then:
1. Open Terminal (Ctrl + ` or View → Terminal)
2. Copy & paste this command:
   ```bash
   npx create-react-app fatuma-portfolio
   ```
3. Wait for it to finish (2-3 minutes)
4. Then type:
   ```bash
   cd fatuma-portfolio
   ```

---

### STEP 3: Install Required Package
Copy & paste:
```bash
npm install lucide-react
```

---

### STEP 4: Setup Files
You need to copy the provided files into your project:

**File 1: src/App.jsx**
1. Open folder `fatuma-portfolio` in VS Code
2. Go to `src/` folder
3. Delete `App.js` and `App.css`
4. Create new file: `src/App.jsx`
5. Copy & paste the portfolio.jsx code into it

**File 2: src/index.js**
1. Open `src/index.js`
2. Replace ALL content with the provided index.js code

**File 3: src/index.css**
1. Open `src/index.css` (should exist)
2. Replace ALL content with the provided index.css code

**File 4: public/index.html**
1. Open `public/index.html`
2. Replace the content between `<head>` tags with the provided HTML

---

### STEP 5: Install Tailwind CSS (Required!)
Tailwind is needed for styling. Copy & paste:
```bash
npm install -D tailwindcss postcss autoprefixer
npx tailwindcss init -p
```

---

### STEP 6: Configure Tailwind
1. Open `tailwind.config.js` (should be in root folder)
2. Replace the content section with:
   ```javascript
   content: [
     "./src/**/*.{js,jsx,ts,tsx}",
   ],
   ```

3. Open `postcss.config.js`
4. Make sure it has:
   ```javascript
   module.exports = {
     plugins: {
       tailwindcss: {},
       autoprefixer: {},
     },
   }
   ```

---

### STEP 7: Start the Website!
Copy & paste:
```bash
npm start
```

**You should see:**
- Terminal message: "Compiled successfully!"
- Browser opens to http://localhost:3000
- Your portfolio website appears! 🎉

---

## Your Project Folder Structure Should Look Like:

```
fatuma-portfolio/
├── node_modules/              (auto-created)
├── public/
│   ├── index.html             (UPDATE THIS)
│   ├── favicon.ico
│   └── robots.txt
├── src/
│   ├── App.jsx                (CREATE THIS - use portfolio.jsx code)
│   ├── index.js               (UPDATE THIS)
│   ├── index.css              (UPDATE THIS)
│   └── logo.svg
├── package.json               (PROVIDED)
├── package-lock.json          (auto-created)
├── tailwind.config.js         (auto-created)
├── postcss.config.js          (auto-created)
└── README.md
```

---

## CUSTOMIZATION (Easy Changes)

### Change Your Name & Contact
Open `src/App.jsx` and find:
- Line with `<span className="font-bold text-xl text-gray-900">Fatuma</span>` - Change "Fatuma" to your name
- `fatumaabdulwaheed@gmail.com` - Change to your email
- `+254 722 214 485` - Change to your phone
- `www.linkedin.com/Fatuma` - Change to your LinkedIn URL

### Change Colors
Find color names like `blue-600` or `indigo-600` in App.jsx

**Common Tailwind colors:**
- `blue`, `indigo`, `purple`, `pink`, `red`, `orange`, `green`, `cyan`
- Numbers: 50 (light) → 900 (dark)
- Example: `from-green-600 to-emerald-600` for green theme

### Update Project Details
Find the `projects` array in App.jsx and update:
- Project names
- Descriptions
- Features
- Process steps
- Tools used

### Update Skills
Find the `skills` object in App.jsx and add/remove skills

---

## COMMON ERRORS & FIXES

| Error | Fix |
|-------|-----|
| `npm is not recognized` | Install Node.js from nodejs.org, restart VS Code |
| `Cannot find module 'lucide-react'` | Run: `npm install lucide-react` |
| `Port 3000 already in use` | Run: `npm start -- --port 3001` |
| Changes not showing | Press Ctrl+R to refresh browser, check terminal for errors |
| `FATAL ERROR: Ineffective mark-compacts` | Close other programs, run: `npm start` again |

---

## DEPLOY TO THE WEB (Pick One)

### Option 1: Vercel (Easiest)
1. Build your project:
   ```bash
   npm run build
   ```
2. Go to https://vercel.com
3. Click "Create Account" (use GitHub, Google, or email)
4. Click "Add New..." → "Project"
5. Upload your `build` folder
6. Your site is LIVE! 🚀

### Option 2: Netlify
1. Build:
   ```bash
   npm run build
   ```
2. Go to https://netlify.com
3. Drag & drop your `build` folder
4. Done!

### Option 3: GitHub Pages
1. Create GitHub account at github.com
2. Create new repository: `fatuma-portfolio`
3. In your project, create `gh-pages` branch
4. Push `build` folder to GitHub
5. Site goes live at: `yourusername.github.io/fatuma-portfolio`

---

## TESTING YOUR WEBSITE

**While running (npm start):**
- Open browser to http://localhost:3000
- Test all buttons and links
- Scroll through all sections
- Try mobile view (press F12, then phone icon)
- Check that it looks good on phone

**Before deploying:**
- Make sure all links work
- Check grammar/spelling
- Test on mobile and desktop
- Update contact info

---

## HELPFUL COMMANDS CHEAT SHEET

```bash
# Start the website (test locally)
npm start

# Build for deployment (creates 'build' folder)
npm run build

# Stop running the website
Ctrl + C

# Install a new package
npm install [package-name]

# See what packages are installed
npm list
```

---

## NEXT STEPS

✅ Complete Step 1-7 above  
✅ Website should be running at localhost:3000  
✅ Customize your information  
✅ Test on mobile & desktop  
✅ Deploy to Vercel/Netlify  
✅ Share your live link with companies!  

---

## RESOURCES

- **React Docs:** https://react.dev
- **Tailwind CSS:** https://tailwindcss.com/docs
- **Lucide Icons:** https://lucide.dev
- **Node.js:** https://nodejs.org/en/docs/

---

## NEED HELP?

- Check VS Code terminal for red error messages
- Google the error message
- Check React docs at react.dev
- Make sure you've installed Node.js and restarted VS Code

**Good luck! You've got this! 🚀**
